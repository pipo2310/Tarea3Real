#include "Integrante.h"

Integrante::Integrante()
{
    //ctor
}

Integrante::~Integrante()
{
    //dtor
}
