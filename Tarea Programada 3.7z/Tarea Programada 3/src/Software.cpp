#include "Software.h"
#include "Grupo.h"
Software::Software()
{
    //ctor
}
Software::Software(string n)
{
    nombre=n;
}

Software::~Software()
{
    //dtor
}

void Software::agregueRequerimento()
{
    string nom;
    string t;

    cout<<"Nombre del requerimento: "<<endl;
    cin>>nom;
    cout<<"Tipo: "<<endl;
    cin>>t;

    Requerimentos *r=new Requerimentos();
    r->setDatos(nom, t);
    r->setTareas();

    listaRequer.push_back(r);
}

string Software::muestreRequerimentos()
{
    stringstream requerimentos;
    list<Requerimentos*>::iterator iter;
    for(iter=listaRequer.begin(); iter!=listaRequer.end(); iter++)
    {
        requerimentos<<"Nombre: "<<(*iter)->getN()<<"\n"<<"Tipo: "<<(*iter)->getTipo()<<"\n"<<(*iter)->muestreTareas()<<endl;
    }
    return requerimentos.str();
}

void Software::modifiqueRequerimento(int instruccion)
{
    list<Requerimentos*>::iterator iter;
    string nv="";
    bool encontrado=false;
    switch(instruccion)
    {
    case 1: //modifique nombre
    {
        string nn="";

        cout<<"Nombre del requerimento a modificar: "<<endl;
        cin>>nv;
        cout<<"Nuevo nombre del requerimento: "<<endl;
        cin>>nn;
        for(iter=listaRequer.begin(); iter!=listaRequer.end(); iter++)
        {
            if((*iter)->getN()==nv)
            {
                (*iter)->setNombre(nn);
                encontrado=true;
            }
        }
        if(!encontrado)
        {
            cout<<"No existe un requerimento con ese nombre"<<endl;
        }
        break;
    }
    case 2: //modifique tipo
    {
        nv="";
        string tn="";

        cout<<"Nombre del requerimento a modificar: "<<endl;
        cin>>nv;
        cout<<"Nuevo tipo del requerimento: "<<endl;
        cin>>tn;
        for(iter=listaRequer.begin(); iter!=listaRequer.end(); iter++)
        {
            if((*iter)->getN()==nv)
            {
                (*iter)->setTipo(tn);
                encontrado=true;
            }
        }
        if(!encontrado)
        {
            cout<<"No existe un requerimento con ese nombre"<<endl;
        }
        break;
    }
    case 3: //agregue tarea
        string nr;
        string n;
        int p;
        float esfEst;
        list<Requerimentos*>::iterator iter;

        cout<<"Nombre de la nueva tarea: "<<endl;
        cin>>n;
        cout<<"Prioridad: "<<endl;
        cin>>p;
        cout<<"Esfuerzo estimado: "<<endl;
        cin>>esfEst;
        Tarea *t1=new Tarea();
        t1->setTarea(n, p, esfEst);
        while(!encontrado)
        {
            cout<<"Nombre del requerimento al que se le asociar� la tarea: "<<endl;
            cin>>nr;
            for(iter=listaRequer.begin(); iter!=listaRequer.end(); iter++)
            {
                if((*iter)->getN()==nr)
                {
                    (*iter)->guardeTarea(t1);
                    encontrado=true;
                }
            }
            if(!encontrado)
            {
                cout<<"Ese nombre no corresponde al de ningun requerimento, ingrese el nombre correctamente"<<endl;
            }
        }
        delete t1;
        break;
    }
}

void Software::borre(int instruc)
{
    string nomReq="";
    list<Requerimentos*>::iterator it;
    if(instruc==1)
    {
        cout<<"Nombre del requerimento a borrar: "<<endl;
        cin>>nomReq;
        {
            for(it=listaRequer.begin(); it!=listaRequer.end(); it++)
            {
                if((*it)->getN()==nomReq)
                {
                    it=listaRequer.erase(it);
                }
            }
        }
    }
    else if(instruc==2)
    {
        cout<<"Nombre del requerimento asociado a la tarea a borrar: "<<endl;
        cin>>nomReq;
        string nomTarea="";
        cout<<"Nombre de la tarea a borrar: "<<endl;
        cin>>nomTarea;
        for(it=listaRequer.begin(); it!=listaRequer.end(); it++)
        {
            if((*it)->getN()==nomReq)
            {
                (*it)->borreTar(nomTarea);
            }
        }
    }
}
void Software::asignarTareas(string req)
{
    list<Requerimentos*>::iterator it;
    list<Miembro*>::iterator itera;

    multimap<int, Tarea*>::iterator ite;
    Grupo grupo;
    list<Miembro*>lis=grupo.getGrupo();

    int contador=0;
    int sumaHoras=0;
    float promedio=0;
    for(it=listaRequer.begin(); it!=listaRequer.end(); it++)
    {
        if((*it)->getN()==req)
        {
            multimap<int, Tarea*>mapa=(*it)->getListaTareas();
            for(ite=mapa.begin(); ite!=mapa.end(); ite++)
            {
                sumaHoras=sumaHoras+(*ite).second->getEsf();
                contador++;
                for(itera=lis.begin();itera!=lis.end();itera++)
                    {
                       (*itera)->addLista((*ite).second);
                    }
            }
            promedio=sumaHoras/contador;

        }
    }
    cout<<sumaHoras<<contador<<promedio<<endl;
}
