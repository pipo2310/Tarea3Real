#include "Requerimentos.h"

Requerimentos::Requerimentos()
{
    nombre="";
    tipo="";

}

void Requerimentos::setDatos(string n, string t){
    nombre=n;
    tipo=t;
}

void Requerimentos::setNombre(string n){
    nombre=n;
}
void Requerimentos::setTipo(string t){
    tipo=t;
}

void Requerimentos::setTareas(){
    int resp=1;
    string n;
    int p;
    float e;
    while(resp!=0){
        if(resp!=0){
        cout<<"Nombre de la tarea a realizar: "<<endl;
        cin>>n;
        cout<<"Prioridad de la tarea: "<<endl;
        cin>>p;
        cout<<"Esfuerzo estimado: "<<endl;
        cin>>e;
        Tarea *t=new Tarea();
        t->setTarea(n, p, e);
        listaDeTareas.insert(make_pair(t->getPrioridad(), t));
        cout<<"Si ya no desea escribir mas tareas escriba 0"<<endl;
        cin>>resp;
        }
    }
}

void Requerimentos::guardeTarea(Tarea *t1){
    listaDeTareas.insert(make_pair(t1->getPrioridad(), t1));
}


string Requerimentos::getN(){
    return nombre;
}

string Requerimentos::getTipo(){
    return tipo;
}
multimap<int, Tarea*> Requerimentos::getListaTareas()
{
    return listaDeTareas;
}

string Requerimentos::muestreTareas(){
    stringstream tareas;
    multimap<int, Tarea*>::iterator it;
    for(it=listaDeTareas.begin();it!=listaDeTareas.end();it++){
        tareas<<((*it).second)->getDatos()<<endl;
    }
    return tareas.str();
}

void Requerimentos::borreTar(string nom){
    multimap<int, Tarea*>::iterator it;
    for(it=listaDeTareas.begin();it!=listaDeTareas.end();it++){
        if((*it).second->getNombre()==nom){
            it=listaDeTareas.erase(it);
        }
    }
}
//void Requerimentos::getPromedioHoras()
//{
//
//}
void Requerimentos::modifiqueTarea(int resp)
{

}
