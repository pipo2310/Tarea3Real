#include "Grupo.h"

Grupo::Grupo()
{
    //ctor
}

Grupo::~Grupo()
{
    //dtor
}

void Grupo::guardeMiembro(Miembro *m){
    grupoDeTrabajo.push_back(m);
}
list<Miembro*> Grupo::getGrupo()
{
    return grupoDeTrabajo;
}

string Grupo::muestreGrupo(){
    stringstream data;
    list<Miembro*>::iterator it;
    for(it=grupoDeTrabajo.begin();it!=grupoDeTrabajo.end();it++){
        data<<(*it)->getDatosMiembro()<<endl;
    }
    return data.str();
}
