#ifndef REQUERIMENTOS_H
#define REQUERIMENTOS_H
#include <sstream>
#include <map>
#include "Tarea.h"

class Requerimentos
{
    public:
        Requerimentos();
        void setTareas();
        void guardeTarea(Tarea*);
        void setDatos(string, string);
        string muestreTareas();
        string getN();
        string getTipo();
        void setNombre(string);
        void setTipo(string);
        void borreTar(string);
        void modifiqueTarea(int);
        multimap<int, Tarea*> getListaTareas();


    protected:
        string tipo;
        string nombre;
        multimap<int, Tarea*> listaDeTareas;

    private:
};

#endif // REQUERIMENTOS_H
