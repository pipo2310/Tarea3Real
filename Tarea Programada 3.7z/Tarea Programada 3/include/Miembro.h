#ifndef MIEMBRO_H
#define MIEMBRO_H
#include "Tarea.h"
#include <list>
#include <sstream>

using namespace std;

class Miembro
{
public:
    Miembro();
    Miembro(string,list<Tarea*>);
    virtual ~Miembro();
    void setNombreMiembro(string);
    string getNombreMiembro();
    string getDatosMiembro();
    void addLista(Tarea* t);


protected:
    string nombreMiembro;
    list<Tarea*> tareasPorRealizar;
private:
};

#endif // MIEMBRO_H
