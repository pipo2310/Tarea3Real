#ifndef INTEGRANTE_H
#define INTEGRANTE_H


class Integrante
{
    public:
        Integrante();
        virtual ~Integrante();

    protected:
        string nombre
    private:
};

#endif // INTEGRANTE_H
