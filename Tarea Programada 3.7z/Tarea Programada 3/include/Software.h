#ifndef SOFTWARE_H
#define SOFTWARE_H
#include "Requerimentos.h"
#include "Tarea.h"
#include <list>
#include <sstream>

using namespace std;

class Software
{
    public:
        Software();
        Software(string);
        virtual ~Software();
        void agregueRequerimento();
        string muestreRequerimentos();
        void modifiqueRequerimento(int);
        void borre(int);
        void asignarTareas(string);


    protected:
        string nombre;
        list<Requerimentos*> listaRequer;
    private:
};

#endif // SOFTWARE_H
